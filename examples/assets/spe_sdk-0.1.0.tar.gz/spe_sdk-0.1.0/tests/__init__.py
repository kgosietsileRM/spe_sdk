"""SPE SDK test suite."""
